"use client"

import { useState } from "react"
import Link from "next/link"
import Image from "next/image"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { ImageUploader } from "@/components/image-uploader"
import { CameraCapture } from "@/components/camera-capture"
import { DetectionResults } from "@/components/detection-results"
import { ArrowLeft, Info } from "lucide-react"

export default function DetectPage() {
  const [image, setImage] = useState<string | null>(null)
  const [isProcessing, setIsProcessing] = useState(false)
  const [results, setResults] = useState<any[] | null>(null)

  const handleImageCapture = (imageData: string) => {
    setImage(imageData)
    setResults(null)
  }

  const handleDetect = async () => {
    if (!image) return

    setIsProcessing(true)

    try {
      // Mock API call to your backend
      // Replace with actual API call to your backend
      await new Promise((resolve) => setTimeout(resolve, 2000))

      // Mock results - replace with actual API response
      setResults([
        {
          id: 1,
          name: "Adhipati Marma",
          position: { x: 50, y: 10 },
          description: "Located at the crown of the head, this point helps with headaches and mental clarity.",
        },
        {
          id: 2,
          name: "Shringataka Marma",
          position: { x: 50, y: 20 },
          description: "Located at the center of the forehead, this point helps with sinus issues and concentration.",
        },
        {
          id: 3,
          name: "Sthapani Marma",
          position: { x: 50, y: 25 },
          description: "Located between the eyebrows, this point helps with stress and anxiety.",
        },
        {
          id: 4,
          name: "Hridaya Marma",
          position: { x: 50, y: 45 },
          description: "Located at the heart center, this point helps with emotional balance and heart health.",
        },
        {
          id: 5,
          name: "Nabhi Marma",
          position: { x: 50, y: 55 },
          description: "Located at the navel, this point helps with digestion and core energy.",
        },
      ])
    } catch (error) {
      console.error("Error detecting points:", error)
    } finally {
      setIsProcessing(false)
    }
  }

  const resetDetection = () => {
    setImage(null)
    setResults(null)
  }

  return (
    <div className="container max-w-6xl py-8">
      <div className="flex items-center gap-4 mb-8">
        <Link href="/">
          <Button variant="ghost" size="icon">
            <ArrowLeft className="h-5 w-5" />
          </Button>
        </Link>
        <h1 className="text-3xl font-bold">Marma Points Detection</h1>
      </div>

      {!results ? (
        <>
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 mb-8">
            <Card className="col-span-1">
              <CardContent className="p-6">
                <h2 className="text-xl font-semibold mb-4">Capture or Upload Image</h2>
                <Tabs defaultValue="upload" className="w-full">
                  <TabsList className="grid w-full grid-cols-2 mb-4">
                    <TabsTrigger value="upload">Upload Image</TabsTrigger>
                    <TabsTrigger value="camera">Use Camera</TabsTrigger>
                  </TabsList>
                  <TabsContent value="upload" className="mt-0">
                    <ImageUploader onImageSelected={handleImageCapture} />
                  </TabsContent>
                  <TabsContent value="camera" className="mt-0">
                    <CameraCapture onImageCaptured={handleImageCapture} />
                  </TabsContent>
                </Tabs>
              </CardContent>
            </Card>

            <Card className="col-span-1">
              <CardContent className="p-6">
                <h2 className="text-xl font-semibold mb-4">Preview</h2>
                <div className="aspect-video bg-muted rounded-lg overflow-hidden flex items-center justify-center">
                  {image ? (
                    <Image
                      src={image || "/placeholder.svg"}
                      alt="Preview"
                      width={500}
                      height={300}
                      className="w-full h-full object-contain"
                    />
                  ) : (
                    <div className="text-muted-foreground flex flex-col items-center gap-2">
                      <Info className="h-8 w-8" />
                      <p>No image selected</p>
                    </div>
                  )}
                </div>
              </CardContent>
            </Card>
          </div>

          <div className="flex justify-center">
            <Button size="lg" onClick={handleDetect} disabled={!image || isProcessing} className="px-8">
              {isProcessing ? "Processing..." : "Detect Marma Points"}
            </Button>
          </div>
        </>
      ) : (
        <DetectionResults image={image!} results={results} onReset={resetDetection} />
      )}
    </div>
  )
}
