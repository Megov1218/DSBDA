"use client"

import { useState, useRef, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Camera, RefreshCw } from "lucide-react"

interface CameraCaptureProps {
  onImageCaptured: (imageData: string) => void
}

export function CameraCapture({ onImageCaptured }: CameraCaptureProps) {
  const [isStreaming, setIsStreaming] = useState(false)
  const [isCaptured, setIsCaptured] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const videoRef = useRef<HTMLVideoElement>(null)
  const canvasRef = useRef<HTMLCanvasElement>(null)

  const startCamera = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({
        video: { facingMode: "environment" },
      })

      if (videoRef.current) {
        videoRef.current.srcObject = stream
        setIsStreaming(true)
        setError(null)
      }
    } catch (err) {
      console.error("Error accessing camera:", err)
      setError("Could not access camera. Please ensure you've granted camera permissions.")
    }
  }

  const stopCamera = () => {
    if (videoRef.current && videoRef.current.srcObject) {
      const tracks = (videoRef.current.srcObject as MediaStream).getTracks()
      tracks.forEach((track) => track.stop())
      videoRef.current.srcObject = null
      setIsStreaming(false)
    }
  }

  const captureImage = () => {
    if (videoRef.current && canvasRef.current) {
      const video = videoRef.current
      const canvas = canvasRef.current
      const context = canvas.getContext("2d")

      if (context) {
        canvas.width = video.videoWidth
        canvas.height = video.videoHeight
        context.drawImage(video, 0, 0, canvas.width, canvas.height)

        const imageData = canvas.toDataURL("image/png")
        onImageCaptured(imageData)
        setIsCaptured(true)
        stopCamera()
      }
    }
  }

  const resetCapture = () => {
    setIsCaptured(false)
    startCamera()
  }

  useEffect(() => {
    startCamera()

    return () => {
      stopCamera()
    }
  }, [])

  return (
    <div className="flex flex-col gap-4">
      <div className="relative aspect-video bg-black rounded-lg overflow-hidden">
        {error ? (
          <div className="absolute inset-0 flex items-center justify-center text-white p-4 text-center">
            <p>{error}</p>
          </div>
        ) : (
          <>
            <video ref={videoRef} autoPlay playsInline muted className="w-full h-full object-cover" />
            <canvas ref={canvasRef} className="hidden" />
          </>
        )}
      </div>

      <div className="flex justify-center gap-4">
        {isStreaming && !isCaptured ? (
          <Button onClick={captureImage} className="gap-2">
            <Camera className="h-4 w-4" />
            Capture
          </Button>
        ) : !error ? (
          <Button onClick={resetCapture} className="gap-2">
            <RefreshCw className="h-4 w-4" />
            Reset Camera
          </Button>
        ) : (
          <Button onClick={startCamera} className="gap-2">
            <Camera className="h-4 w-4" />
            Try Again
          </Button>
        )}
      </div>
    </div>
  )
}
