"use client"

import { useState } from "react"
import Image from "next/image"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { ArrowLeft, Info, Maximize, Minimize } from "lucide-react"

interface MarmaPoint {
  id: number
  name: string
  position: {
    x: number
    y: number
  }
  description: string
}

interface DetectionResultsProps {
  image: string
  results: MarmaPoint[]
  onReset: () => void
}

export function DetectionResults({ image, results, onReset }: DetectionResultsProps) {
  const [selectedPoint, setSelectedPoint] = useState<MarmaPoint | null>(null)
  const [isFullscreen, setIsFullscreen] = useState(false)

  const handlePointClick = (point: MarmaPoint) => {
    setSelectedPoint(point)
  }

  const toggleFullscreen = () => {
    setIsFullscreen(!isFullscreen)
  }

  return (
    <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
      <div
        className={`${isFullscreen ? "fixed inset-0 z-50 p-4 bg-background/95 flex items-center justify-center" : "lg:col-span-2"}`}
      >
        <div
          className={`relative ${isFullscreen ? "max-h-[90vh] max-w-[90vw]" : "aspect-video"} bg-black rounded-lg overflow-hidden`}
        >
          <Image src={image || "/placeholder.svg"} alt="Analyzed image" fill className="object-contain" />

          {/* Marma points overlay */}
          <div className="absolute inset-0">
            {results.map((point) => (
              <button
                key={point.id}
                className={`absolute w-6 h-6 rounded-full border-2 -translate-x-1/2 -translate-y-1/2 transition-all duration-300 ${
                  selectedPoint?.id === point.id
                    ? "bg-primary border-white scale-125 z-20"
                    : "bg-primary/70 border-white/70 hover:scale-110 z-10"
                }`}
                style={{
                  left: `${point.position.x}%`,
                  top: `${point.position.y}%`,
                }}
                onClick={() => handlePointClick(point)}
                aria-label={`Select ${point.name}`}
              >
                <span className="sr-only">{point.name}</span>
              </button>
            ))}
          </div>

          <button
            className="absolute top-2 right-2 p-2 bg-background/80 rounded-full hover:bg-background/90 transition-colors"
            onClick={toggleFullscreen}
            aria-label={isFullscreen ? "Exit fullscreen" : "Enter fullscreen"}
          >
            {isFullscreen ? <Minimize className="h-5 w-5" /> : <Maximize className="h-5 w-5" />}
          </button>
        </div>

        {isFullscreen && (
          <button
            className="fixed top-4 left-4 p-2 bg-background rounded-full hover:bg-muted transition-colors"
            onClick={toggleFullscreen}
            aria-label="Close fullscreen view"
          >
            <ArrowLeft className="h-5 w-5" />
          </button>
        )}
      </div>

      <div className="lg:col-span-1">
        <Card className="h-full">
          <CardHeader>
            <CardTitle>Detected Marma Points</CardTitle>
            <CardDescription>{results.length} points found on your image</CardDescription>
          </CardHeader>
          <CardContent>
            <Tabs defaultValue="list" className="w-full">
              <TabsList className="grid w-full grid-cols-2 mb-4">
                <TabsTrigger value="list">List View</TabsTrigger>
                <TabsTrigger value="details">Details</TabsTrigger>
              </TabsList>

              <TabsContent value="list" className="mt-0 space-y-4">
                <div className="space-y-2">
                  {results.map((point) => (
                    <div
                      key={point.id}
                      className={`p-3 rounded-lg cursor-pointer transition-colors ${
                        selectedPoint?.id === point.id ? "bg-primary/10 border-l-4 border-primary" : "hover:bg-muted"
                      }`}
                      onClick={() => handlePointClick(point)}
                    >
                      <h3 className="font-medium">{point.name}</h3>
                      <p className="text-sm text-muted-foreground line-clamp-1">{point.description}</p>
                    </div>
                  ))}
                </div>
              </TabsContent>

              <TabsContent value="details" className="mt-0">
                {selectedPoint ? (
                  <div className="space-y-4">
                    <div className="p-4 bg-muted rounded-lg">
                      <h3 className="text-xl font-semibold mb-2">{selectedPoint.name}</h3>
                      <p className="text-muted-foreground">{selectedPoint.description}</p>
                    </div>

                    <div className="space-y-2">
                      <h4 className="font-medium">Benefits:</h4>
                      <ul className="list-disc list-inside space-y-1 text-muted-foreground">
                        <li>Relieves tension and stress</li>
                        <li>Improves energy flow</li>
                        <li>Enhances organ function</li>
                        <li>Promotes overall wellness</li>
                      </ul>
                    </div>

                    <div className="space-y-2">
                      <h4 className="font-medium">How to Activate:</h4>
                      <p className="text-muted-foreground">
                        Apply gentle pressure with your thumb or finger for 1-3 minutes in a circular motion. Practice
                        deep breathing while applying pressure.
                      </p>
                    </div>
                  </div>
                ) : (
                  <div className="flex flex-col items-center justify-center py-8 text-center text-muted-foreground">
                    <Info className="h-12 w-12 mb-4 opacity-50" />
                    <p>Select a marma point to view detailed information</p>
                  </div>
                )}
              </TabsContent>
            </Tabs>

            <div className="mt-6">
              <Button onClick={onReset} variant="outline" className="w-full">
                <ArrowLeft className="h-4 w-4 mr-2" />
                Start New Detection
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
