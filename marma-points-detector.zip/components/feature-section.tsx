import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Brain, Camera, Zap, BookOpen, Heart, Shield } from "lucide-react"

export function FeatureSection() {
  const features = [
    {
      icon: <Brain className="h-10 w-10 text-primary" />,
      title: "AI-Powered Detection",
      description: "Our advanced AI algorithms accurately identify marma points on any body type.",
    },
    {
      icon: <Camera className="h-10 w-10 text-primary" />,
      title: "Real-time Analysis",
      description: "Upload an image or use your camera for instant marma point detection.",
    },
    {
      icon: <Zap className="h-10 w-10 text-primary" />,
      title: "Personalized Insights",
      description: "Get detailed information about each marma point and its healing properties.",
    },
    {
      icon: <BookOpen className="h-10 w-10 text-primary" />,
      title: "Ancient Wisdom",
      description: "Access thousands of years of Ayurvedic knowledge in a modern application.",
    },
    {
      icon: <Heart className="h-10 w-10 text-primary" />,
      title: "Holistic Wellness",
      description: "Improve your overall well-being by targeting specific marma points.",
    },
    {
      icon: <Shield className="h-10 w-10 text-primary" />,
      title: "Privacy First",
      description: "Your images and data are processed securely and never stored without consent.",
    },
  ]

  return (
    <section id="features" className="py-20 bg-background">
      <div className="container px-4 md:px-6">
        <div className="text-center mb-12">
          <h2 className="text-3xl font-bold tracking-tighter sm:text-4xl md:text-5xl">Powerful Features</h2>
          <p className="mt-4 text-muted-foreground max-w-[700px] mx-auto">
            Our marma point detection system combines cutting-edge technology with ancient healing wisdom.
          </p>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {features.map((feature, index) => (
            <Card key={index} className="border-2 hover:border-primary/50 transition-all duration-300">
              <CardHeader>
                <div className="mb-2">{feature.icon}</div>
                <CardTitle>{feature.title}</CardTitle>
              </CardHeader>
              <CardContent>
                <CardDescription className="text-base">{feature.description}</CardDescription>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </section>
  )
}
