import Image from "next/image"
import { Card, CardContent, CardFooter } from "@/components/ui/card"
import { Star } from "lucide-react"

export function Testimonials() {
  const testimonials = [
    {
      name: "Sarah Johnson",
      role: "Yoga Instructor",
      content:
        "This app has revolutionized how I teach my students about marma points. The detection is incredibly accurate and the information provided is comprehensive.",
      avatar: "/placeholder.svg?height=100&width=100",
      rating: 5,
    },
    {
      name: "Dr. Michael Chen",
      role: "Acupuncturist",
      content:
        "As a professional in alternative medicine, I'm impressed by the precision of this tool. It's become an essential part of my practice for educating patients.",
      avatar: "/placeholder.svg?height=100&width=100",
      rating: 5,
    },
    {
      name: "Priya Patel",
      role: "Ayurvedic Practitioner",
      content:
        "The MarmaPoint detector bridges ancient wisdom with modern technology beautifully. My clients are amazed when they see their marma points visualized so clearly.",
      avatar: "/placeholder.svg?height=100&width=100",
      rating: 5,
    },
  ]

  return (
    <section className="py-20 bg-background">
      <div className="container px-4 md:px-6">
        <div className="text-center mb-12">
          <h2 className="text-3xl font-bold tracking-tighter sm:text-4xl md:text-5xl">What Our Users Say</h2>
          <p className="mt-4 text-muted-foreground max-w-[700px] mx-auto">
            Discover how our marma point detection technology is helping professionals and enthusiasts alike.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {testimonials.map((testimonial, index) => (
            <Card key={index} className="border-2 hover:border-primary/50 transition-all duration-300">
              <CardContent className="p-6 pt-8">
                <div className="flex mb-4">
                  {Array(testimonial.rating)
                    .fill(0)
                    .map((_, i) => (
                      <Star key={i} className="h-5 w-5 fill-primary text-primary" />
                    ))}
                </div>
                <p className="italic mb-6">"{testimonial.content}"</p>
              </CardContent>
              <CardFooter className="p-6 pt-0 flex items-center gap-4">
                <div className="relative w-12 h-12 rounded-full overflow-hidden">
                  <Image
                    src={testimonial.avatar || "/placeholder.svg"}
                    alt={testimonial.name}
                    fill
                    className="object-cover"
                  />
                </div>
                <div>
                  <h4 className="font-semibold">{testimonial.name}</h4>
                  <p className="text-sm text-muted-foreground">{testimonial.role}</p>
                </div>
              </CardFooter>
            </Card>
          ))}
        </div>
      </div>
    </section>
  )
}
