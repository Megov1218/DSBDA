import Link from "next/link"
import { Button } from "@/components/ui/button"

export function CTASection() {
  return (
    <section className="py-20 bg-primary/5">
      <div className="container px-4 md:px-6">
        <div className="flex flex-col items-center text-center max-w-[800px] mx-auto">
          <h2 className="text-3xl font-bold tracking-tighter sm:text-4xl md:text-5xl mb-6">
            Ready to Discover Your Body's Healing Points?
          </h2>
          <p className="text-lg text-muted-foreground mb-8 max-w-[600px]">
            Start your journey to better health and wellness by exploring the ancient wisdom of marma points with our
            cutting-edge detection technology.
          </p>
          <Link href="/detect">
            <Button size="lg" className="px-8 text-lg">
              Try It Now
            </Button>
          </Link>
        </div>
      </div>
    </section>
  )
}
