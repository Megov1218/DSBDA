import Image from "next/image"
import { Card, CardContent } from "@/components/ui/card"
import { Camera, Scan, FileText, ThumbsUp } from "lucide-react"

export function HowItWorks() {
  const steps = [
    {
      icon: <Camera className="h-8 w-8 text-primary" />,
      title: "Capture or Upload",
      description: "Take a photo or upload an existing image of the body area you want to analyze.",
    },
    {
      icon: <Scan className="h-8 w-8 text-primary" />,
      title: "AI Detection",
      description: "Our AI analyzes the image to identify marma points with precision.",
    },
    {
      icon: <FileText className="h-8 w-8 text-primary" />,
      title: "Get Insights",
      description: "View detailed information about each detected marma point and its benefits.",
    },
    {
      icon: <ThumbsUp className="h-8 w-8 text-primary" />,
      title: "Apply Knowledge",
      description: "Use the insights to apply pressure to specific points for therapeutic benefits.",
    },
  ]

  return (
    <section id="how-it-works" className="py-20 bg-muted">
      <div className="container px-4 md:px-6">
        <div className="text-center mb-12">
          <h2 className="text-3xl font-bold tracking-tighter sm:text-4xl md:text-5xl">How It Works</h2>
          <p className="mt-4 text-muted-foreground max-w-[700px] mx-auto">
            Our simple four-step process makes marma point detection accessible to everyone.
          </p>
        </div>

        <div className="relative">
          <div className="hidden md:block absolute top-1/2 left-0 right-0 h-1 bg-primary/30 -translate-y-1/2 z-0"></div>
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
            {steps.map((step, index) => (
              <Card
                key={index}
                className="relative z-10 bg-background border-2 hover:border-primary/50 transition-all duration-300"
              >
                <CardContent className="p-6 flex flex-col items-center text-center">
                  <div className="w-16 h-16 rounded-full bg-primary/10 flex items-center justify-center mb-4">
                    {step.icon}
                  </div>
                  <div className="absolute top-0 left-1/2 -translate-x-1/2 -translate-y-1/2 w-8 h-8 rounded-full bg-primary text-white flex items-center justify-center font-bold text-sm md:block hidden">
                    {index + 1}
                  </div>
                  <h3 className="text-xl font-bold mb-2">{step.title}</h3>
                  <p className="text-muted-foreground">{step.description}</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>

        <div className="mt-16 bg-background rounded-lg overflow-hidden shadow-lg">
          <div className="grid grid-cols-1 lg:grid-cols-2">
            <div className="p-8 flex flex-col justify-center">
              <h3 className="text-2xl font-bold mb-4">See the Technology in Action</h3>
              <p className="text-muted-foreground mb-6">
                Our advanced AI can detect over 107 marma points across the human body, providing precise locations and
                detailed information about each point's therapeutic properties.
              </p>
              <ul className="space-y-2">
                <li className="flex items-center gap-2">
                  <div className="w-2 h-2 rounded-full bg-primary"></div>
                  <span>High-precision detection algorithms</span>
                </li>
                <li className="flex items-center gap-2">
                  <div className="w-2 h-2 rounded-full bg-primary"></div>
                  <span>Works with any body type or position</span>
                </li>
                <li className="flex items-center gap-2">
                  <div className="w-2 h-2 rounded-full bg-primary"></div>
                  <span>Detailed information for each point</span>
                </li>
                <li className="flex items-center gap-2">
                  <div className="w-2 h-2 rounded-full bg-primary"></div>
                  <span>Therapeutic recommendations</span>
                </li>
              </ul>
            </div>
            <div className="relative h-[300px] lg:h-auto">
              <Image
                src="/placeholder.svg?height=400&width=600"
                alt="Marma point detection demo"
                fill
                className="object-cover"
              />
              <div className="absolute inset-0 flex items-center justify-center">
                <div className="w-16 h-16 rounded-full bg-primary/80 flex items-center justify-center">
                  <div className="w-0 h-0 border-t-8 border-t-transparent border-l-12 border-l-white border-b-8 border-b-transparent ml-1"></div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}
