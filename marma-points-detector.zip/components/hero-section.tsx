import Link from "next/link"
import Image from "next/image"
import { Button } from "@/components/ui/button"

export function HeroSection() {
  return (
    <section className="relative py-20 md:py-32 overflow-hidden bg-gradient-to-b from-background to-muted">
      <div className="container px-4 md:px-6">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
          <div className="flex flex-col gap-6">
            <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold tracking-tighter">
              Discover Your Body's <span className="text-primary">Healing Points</span>
            </h1>
            <p className="text-lg text-muted-foreground max-w-[600px]">
              Our advanced AI technology detects marma points on your body, unlocking ancient healing wisdom for modern
              wellness. Experience the power of targeted acupressure therapy.
            </p>
            <div className="flex flex-col sm:flex-row gap-4">
              <Link href="/detect">
                <Button size="lg" className="px-8">
                  Start Detection
                </Button>
              </Link>
              <Link href="#how-it-works">
                <Button size="lg" variant="outline" className="px-8">
                  Learn More
                </Button>
              </Link>
            </div>
          </div>
          <div className="relative h-[400px] lg:h-[500px] rounded-lg overflow-hidden">
            <div className="absolute inset-0 bg-gradient-to-r from-primary/20 to-primary/5 rounded-lg z-10"></div>
            <Image
              src="/placeholder.svg?height=500&width=500"
              alt="Marma points visualization"
              fill
              className="object-cover rounded-lg"
              priority
            />
            <div className="absolute inset-0 flex items-center justify-center z-20">
              <div className="w-24 h-24 rounded-full bg-primary/20 animate-pulse"></div>
              <div
                className="absolute w-16 h-16 rounded-full bg-primary/30 animate-pulse"
                style={{ top: "30%", left: "60%" }}
              ></div>
              <div
                className="absolute w-12 h-12 rounded-full bg-primary/40 animate-pulse"
                style={{ top: "70%", left: "40%" }}
              ></div>
            </div>
          </div>
        </div>
      </div>
      <div className="absolute bottom-0 left-0 right-0 h-24 bg-gradient-to-t from-background to-transparent"></div>
    </section>
  )
}
